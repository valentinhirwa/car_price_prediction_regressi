// static/js/charts.js
function renderDashboardCharts() {
  // Feature importance (mock data)
  const ctx1 = document.getElementById('featureImportanceChart');
  if (!ctx1) return;
  if (window._featChart) window._featChart.destroy();

  window._featChart = new Chart(ctx1, {
    type: 'bar',
    data: {
      labels: ['Engine Size', 'Mileage', 'Year', 'Condition', 'Brand', 'Fuel'],
      datasets: [{
        label: 'Feature Importance',
        data: [0.28, 0.24, 0.18, 0.12, 0.10, 0.08],
        backgroundColor: ['#38bdf8', '#0f172a', '#64748b', '#94a3b8', '#cbd5e1', '#e2e8f0'],
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: '#f1f5f9' }
        }
      }
    }
  });

  // Actual vs Predicted (mock scatter)
  const ctx2 = document.getElementById('actualPredictedChart');
  if (!ctx2) return;
  if (window._scatterChart) window._scatterChart.destroy();

  const scatterData = Array.from({ length: 30 }, () => ({
    x: 8000 + Math.random() * 75000,
    y: 8000 + Math.random() * 75000
  }));

  window._scatterChart = new Chart(ctx2, {
    type: 'scatter',
    data: {
      datasets: [{
        label: 'Actual vs Predicted',
        data: scatterData,
        backgroundColor: '#38bdf8',
        pointRadius: 5,
        pointHoverRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: (ctx) => `$ ${ctx.parsed.x.toFixed(0)} → $ ${ctx.parsed.y.toFixed(0)}` } }
      },
      scales: {
        x: {
          title: { display: true, text: 'Actual Price ($)' },
          grid: { color: '#f1f5f9' }
        },
        y: {
          title: { display: true, text: 'Predicted Price ($)' },
          grid: { color: '#f1f5f9' }
        }
      }
    }
  });
}

// Auto-render when dashboard visible
document.addEventListener('DOMContentLoaded', () => {
  // Will be called on nav click
  window.renderDashboardCharts = renderDashboardCharts;
});